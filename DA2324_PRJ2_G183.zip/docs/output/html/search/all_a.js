var searchData=
[
  ['vertex_27',['Vertex',['../classVertex.html',1,'Vertex'],['../classVertex.html#a7aa243a6ff838583880f4c57bce2e40b',1,'Vertex::Vertex()']]]
];
