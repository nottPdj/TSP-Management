var searchData=
[
  ['initmatrix_11',['initMatrix',['../classAuxiliar.html#ab9be846833a64b5ed69c9d2241e99500',1,'Auxiliar']]]
];
